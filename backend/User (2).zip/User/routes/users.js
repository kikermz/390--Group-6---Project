const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

// Define the User schema and model only once
const UserSchema = new mongoose.Schema({
    name: String,
    email: String,
    bio: String,
});

const User = mongoose.model('User', UserSchema);

// Create a new user
router.post('/', async (req, res) => {
    const user = new User(req.body);
    await user.save();
    res.send(user);
});

// Get all users
router.get('/', async (req, res) => {
    const users = await User.find();
    res.send(users);
});

module.exports = router;
