const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
app.use(bodyParser.json());

mongoose.connect('mongodb://localhost/socialmedia');

const usersRouter = require('./routes/users'); // Ensure this path is correct

app.use('/users', usersRouter);

const PORT = process.env.PORT || 3000;

function startServer() {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    }).on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
            console.error(`Port ${PORT} is already in use. Please use a different port.`);
            process.exit(1);
        } else {
            throw err;
        }
    });
}

startServer();
